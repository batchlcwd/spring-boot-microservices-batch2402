package com.elearn.app.dtos;

import lombok.Data;

@Data
public class RoleDto {

    private  String roleId;
    private  String roleName;
}
