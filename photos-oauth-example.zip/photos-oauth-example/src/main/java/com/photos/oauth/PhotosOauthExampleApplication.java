package com.photos.oauth;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PhotosOauthExampleApplication {

	public static void main(String[] args) {
		SpringApplication.run(PhotosOauthExampleApplication.class, args);
	}

}
