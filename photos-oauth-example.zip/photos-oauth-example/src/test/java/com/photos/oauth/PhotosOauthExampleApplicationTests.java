package com.photos.oauth;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PhotosOauthExampleApplicationTests {

	@Test
	void contextLoads() {
	}

}
