package com.service.category.dto;

import lombok.Data;

@Data
public class CustomMessage {
    private String message;
    private boolean success;
}
