package com.service.video.dto;

import lombok.Data;

@Data
public class CustomMessage {
    private String message;
    private boolean success;
}
